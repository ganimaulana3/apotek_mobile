<?php
// upload_bukti.php
include "koneksi.php";
header('content-type: application/json');

// Validasi input
if (!isset($_POST['orderid']) || !isset($_FILES['bukti'])) {
    echo json_encode([
        "kode" => 0,
        "pesan" => "Parameter orderid dan file bukti diperlukan"
    ]);
    exit;
}

$orderid = $_POST['orderid'];

// Upload file
$targetDir = "upload/";
$buktibayar = $_FILES['bukti']['name'];
$targetFile = $targetDir . basename($buktibayar);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Cek apakah file adalah gambar
$check = getimagesize($_FILES['bukti']['tmp_name']);
if ($check === false) {
    $uploadOk = 0;
    $pesan = "File bukan gambar.";
}

// Cek ukuran file (max 2MB)
if ($_FILES['bukti']['size'] > 2000000) {
    $uploadOk = 0;
    $pesan = "Ukuran file terlalu besar (max 2MB).";
}

// Format file yang diizinkan
if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
    $uploadOk = 0;
    $pesan = "Hanya file JPG, JPEG, PNG & GIF yang diizinkan.";
}

// Upload file jika semua validasi ok
if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES['bukti']['tmp_name'], $targetFile)) {
        // Update database dengan bukti pembayaran
        $sql = "UPDATE tbl_order SET buktibayar = '$buktibayar', status = 1 WHERE trans_id = $orderid";
        // Status 2: pembayaran telah diupload (menunggu verifikasi)
        
        if (mysqli_query($conn, $sql)) {
            echo json_encode([
                "kode" => 1,
                "pesan" => "Bukti pembayaran berhasil diupload",
                "filename" => $buktibayar
            ]);
        } else {
            echo json_encode([
                "kode" => 0,
                "pesan" => "Gagal update database: " . mysqli_error($conn)
            ]);
        }
    } else {
        echo json_encode([
            "kode" => 0,
            "pesan" => "Gagal upload file."
        ]);
    }
} else {
    echo json_encode([
        "kode" => 0,
        "pesan" => $pesan
    ]);
}
?>