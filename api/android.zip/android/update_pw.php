<?php
include "koneksi.php";
header('Content-Type: application/json');

$email = mysqli_real_escape_string($conn, $_POST['email']);
$currentPassword = mysqli_real_escape_string($conn, $_POST['current_password']);
$newPassword = mysqli_real_escape_string($conn, $_POST['new_password']);

$getstatus = 0;
$getresult = 0;
$message = "";

// Check if the user exists and the current password is correct
$sql = "SELECT * FROM tbl_pelanggan WHERE email='$email' AND password=MD5('$currentPassword')";
$hasil = mysqli_query($conn, $sql);

if (mysqli_num_rows($hasil) == 0) { // If no user found or password is incorrect
    $getstatus = 0;
    $message = "Email atau password saat ini salah";
} else {
    // Update the password
    $sql = "UPDATE tbl_pelanggan SET password=MD5('$newPassword') WHERE email='$email'";
    $hasil = mysqli_query($conn, $sql);

    if ($hasil) {
        $getstatus = 1;
        $getresult = 1;
        $message = "Password berhasil diubah";
    } else {
        $getstatus = 1;
        $getresult = 0;
        $message = "Gagal mengubah password: " . mysqli_error($conn);
    }
}

// Ensure JSON is always returned
echo json_encode(array('status' => $getstatus, 'result' => $getresult, 'message' => $message));

?>
