<?php

$kota = [
  "Kota Bandung",
  "Kabupaten Bandung"
]

?>