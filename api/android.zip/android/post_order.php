<?php
include "koneksi.php";
header('content-type: application/json');

// Ambil data order dan detail
$order = $_POST['order'];
$order_detail = $_POST['order_detail'];
$hasilorder = json_decode($order);
$hasilorder_detail = json_decode($order_detail);

// Upload file
if (isset($_FILES['bukti'])) {
    $targetDir = "upload/";
    $buktibayar = $_FILES['bukti']['name'];
    $targetFile = $targetDir . $buktibayar;
    move_uploaded_file($_FILES['bukti']['tmp_name'], $targetFile);
} else {
    $buktibayar = '';
}

// Ambil ID terakhir
$sql = "SELECT IFNULL(MAX(trans_id)+1,1) AS trans_id FROM tbl_order";
$hasil = mysqli_query($conn, $sql);
$data = mysqli_fetch_array($hasil);
$id = $data['trans_id'];

// Data order
$nm_penerima = $hasilorder->nm_penerima;
$email = $hasilorder->email;
$tgl_order = date('Y-m-d', time());
$subtotal = $hasilorder->subtotal;
$ongkir = $hasilorder->ongkir;
$total_bayar = $hasilorder->total_bayar;
$alamat_kirim = $hasilorder->alamat_kirim;
$telp_kirim = $hasilorder->telp_kirim;
$kota = $hasilorder->kota;
$provinsi = $hasilorder->provinsi;
$lamakirim = $hasilorder->lamakirim;
$kodepos = $hasilorder->kodepos;
$metodebayar = $hasilorder->metodebayar;
$status = ($metodebayar == 2) ? 0 : 1;

// Insert ke tbl_order
$sql = "INSERT INTO tbl_order (trans_id, nm_penerima, email, tgl_order, subtotal, ongkir, total_bayar,
    alamat_kirim, telp_kirim, kota, provinsi, lamakirim, kodepos, metodebayar, buktibayar, status)
    VALUES ($id, '$nm_penerima', '$email', '$tgl_order', $subtotal, $ongkir, $total_bayar,
    '$alamat_kirim', '$telp_kirim', '$kota', '$provinsi', '$lamakirim', '$kodepos',
    $metodebayar, '$buktibayar', $status)";
    
$hasil = mysqli_query($conn, $sql);
$kode = 0;
$pesan = "Proses Gagal";
$orderid = null;

// Insert detail
if ($hasil) {
    foreach ($hasilorder_detail as $h) {
        $sql = "INSERT INTO tbl_detail_order(trans_id, kode_brg, harga_jual, qty, bayar)
            VALUES ($id, '{$h->kode}', {$h->harga}, {$h->qty}, " . ($h->harga * $h->qty) . ")";
        $hasil = mysqli_query($conn, $sql);
        if ($hasil) {
            // Update stok di tbl_product
            $sqlStok = "UPDATE produk SET stok = stok - {$h->qty} WHERE id_produk = '{$h->kode}'";
            $hasilStok = mysqli_query($conn, $sqlStok);

            if ($hasilStok) {
                $kode = 1;
                $orderid = $id;
                $pesan = "Proses Berhasil";
            } else {
                $kode = 0;
                $pesan = "Gagal update stok: " . mysqli_error($conn);
                break;
            }
        } else {
            $kode = 0;
            $pesan = "Insert detail gagal: " . mysqli_error($conn);
            break;
        }
    }
} else {
    $kode = 0;
    $pesan = "Insert order gagal: " . mysqli_error($conn);
}

// Output
echo json_encode([
    "kode" => $kode,
    "orderid" => $orderid,
    "pesan" => $pesan
]);
?>
