<?php

require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();
include "kota.php";
$searchTerms = ['search?keyword=46333'];
$results = [];

foreach ($searchTerms as $term) {
    $response = $client->request('GET', 'https://rajaongkir.komerce.id/api/v1/destination/domestic-destination', [
        'headers' => [
            'accept' => 'application/json',
            'key' => 'c6d4aa90223851efca907cd7c931cad4',
        ],
        'query' => [
            'search' => $term
        ]
    ]);

    $body = $response->getBody()->getContents();
    $results[$term] = json_decode($body, true);
}

// Print hasil seluruh kota
echo json_encode($results, JSON_PRETTY_PRINT);
