<?php
include "koneksi.php";
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['result' => 0, 'message' => 'Invalid request method.']);
    exit();
}

// Validasi field wajib
$required = ['email', 'nama', 'alamat', 'kota', 'provinsi', 'telp', 'kodepos'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        echo json_encode(['result' => 0, 'message' => "Field $field wajib diisi."]);
        exit();
    }
}

$email     = $_POST['email'];
$nama      = $_POST['nama'];
$alamat    = $_POST['alamat'];
$kota      = $_POST['kota'];
$provinsi  = $_POST['provinsi'];
$telp      = $_POST['telp'];
$kodepos   = $_POST['kodepos'];
$uploadDir = "profile/";
$foto      = null; // Set awal null agar tidak error jika tidak ada file

// Proses upload foto jika ada
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $fileTmp  = $_FILES['foto']['tmp_name'];
    $fileName = basename($_FILES['foto']['name']);
    $fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $newName  = uniqid('IMG_') . '.' . $fileExt;
    $uploadPath = $uploadDir . $newName;

    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($fileExt, $allowedTypes)) {
        echo json_encode(['result' => 0, 'message' => 'Tipe file tidak diizinkan.']);
        exit();
    }

    if (move_uploaded_file($fileTmp, $uploadPath)) {
        $foto = $newName;
    } else {
        echo json_encode(['result' => 0, 'message' => 'Gagal meng-upload foto.']);
        exit();
    }
}

// Update query
if ($foto !== null) {
    $sql = "UPDATE tbl_pelanggan SET nama=?, alamat=?, kota=?, provinsi=?, telp=?, kodepos=?, foto=? WHERE email=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssssss", $nama, $alamat, $kota, $provinsi, $telp, $kodepos, $foto, $email);
} else {
    $sql = "UPDATE tbl_pelanggan SET nama=?, alamat=?, kota=?, provinsi=?, telp=?, kodepos=? WHERE email=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssss", $nama, $alamat, $kota, $provinsi, $telp, $kodepos, $email);
}

$hasil = mysqli_stmt_execute($stmt);

echo json_encode([
    'result' => $hasil ? 1 : 0,
    'message' => $hasil ? "Update Berhasil" : "Update Gagal: " . mysqli_error($conn)
]);

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
