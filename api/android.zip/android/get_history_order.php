<?php
include "koneksi.php";
header('Content-Type: application/json');

// Cek jika ada email yang dikirim (POST atau GET)
$email = $_POST['email'] ?? $_GET['email'] ?? null;

if (!$email) {
    echo json_encode([
        "kode" => 0,
        "pesan" => "Email tidak ditemukan"
    ]);
    exit;
}

$data = [];

// Ambil data order utama
$sql = "SELECT * FROM tbl_order WHERE email = '$email' ORDER BY tgl_order DESC";
$hasil = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($hasil)) {
    $trans_id = $row['trans_id'];

    // Ambil detail barang untuk setiap order
    $sql_detail = "SELECT * FROM tbl_detail_order WHERE trans_id = $trans_id";
    $hasil_detail = mysqli_query($conn, $sql_detail);

    $detail = [];
    while ($d = mysqli_fetch_assoc($hasil_detail)) {
        $detail[] = [
            "kode_brg" => $d['kode_brg'],
            "harga_jual" => $d['harga_jual'],
            "qty" => $d['qty'],
            "bayar" => $d['bayar']
        ];
    }

    // Gabungkan order dan detail
    $data[] = [
        "trans_id" => $row['trans_id'],
        "nm_penerima" => $row['nm_penerima'],
        "tgl_order" => $row['tgl_order'],
        "alamat_kirim" => $row['alamat_kirim'],
        "telp_kirim" => $row['telp_kirim'],
        "kota" => $row['kota'],
        "provinsi" => $row['provinsi'],
        "kodepos" => $row['kodepos'],
        "subtotal" => $row['subtotal'],
        "ongkir" => $row['ongkir'],
        "total_bayar" => $row['total_bayar'],
        "metodebayar" => $row['metodebayar'],
        "buktibayar" => $row['buktibayar'],
        "status" => $row['status'],
        "lamakirim" => $row['lamakirim'],
        "detail" => $detail
    ];
}

// Output data sebagai JSON
echo json_encode([
    "kode" => 1,
    "jumlah" => count($data),
    "data" => $data
]);
?>
